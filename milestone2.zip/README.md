## Project description
We are creating a social media like platform for cornell students. This would allow users to create posts, see other users' posts, log in to their account, and edit their account information.

## Team members
Kody Yang - kyy23
Julia Zeng - jwz28
Lili Mkrtchyan - lm688

## Git repository
https://github.coecis.cornell.edu/jwz28/trends-final-project
