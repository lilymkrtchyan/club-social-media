
export type Post = {
  name: string
  username: string
  text: string
}