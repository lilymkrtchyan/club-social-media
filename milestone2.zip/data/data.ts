import { Post } from "@/types";

export const Post_Data: Post[] = [
  {
    name: "Cornell DTI",
    username: "@CUDTI",
    text: "sadkfgdskafsadjfksdljfhalsjhdflkjahsdlfhljksad",
  },
  {
    name: "Cornell DTI",
    username: "@CUDTI",
    text: "sadkfgdskafsadjfksdljfhalsjhdflkjahsdlfhljksad",
  },
  {
    name: "Cornell DTI",
    username: "@CUDTI",
    text: "sadkfgdskafsadjfksdljfhalsjhdflkjahsdlfhljksad",
  }
]